using System;
using System.Collections.Generic;

namespace GradeBook
{
    public class Book
    {
        public Book(string name)
        {
            grades = new List<double>();
            this.name = name;
        }
        public void AddGrade(double grade)
        {
            grades.Add(grade);
        }

        // public void Calculate()
        // {
        //     foreach(var number in grades)
        //     {
        //         high_grade = Math.Max(number, high_grade);
        //         low_grade = Math.Min(number, low_grade);
        //         result += number;
        //     }
        // }

        // public void ShowStatistics()
        // {
        //     Calculate();
        //     Console.WriteLine($"The average grade is {result /= grades.Count:N1}\nThe high grade is {high_grade}\nThe low grade is {low_grade}");
        // }

        public Statistics GetStatistics()
        {
            var result = new Statistics();
            result.Average = 0.0;
            result.Low = double.MaxValue;
            result.High = double.MinValue;
            foreach(var grade in grades)
            {
                result.High = Math.Max(grade, result.High);
                result.Low = Math.Min(grade, result.Low);
                result.Average += grade;
            }
            result.Average /= grades.Count;

            return result;
        }
        
        private List<double> grades;
        //double high_grade = double.MinValue;
        //double low_grade = double.MaxValue;
        private string name;
    }
}