﻿using System;
using System.Collections.Generic;

namespace GradeBook
{
    class Program
    {
        static void Main(string[] args)
        {
            var book = new Book("Austin's GradeBook");
            book.AddGrade(89.1);
            book.AddGrade(75.2);
            book.AddGrade(66.6);
            book.GetStatistics();
            var stats = book.GetStatistics();
            Console.WriteLine($"The average grade is {stats.Average}\nThe high grade is {stats.High}\nThe low grade is {stats.Low}");
        }
    }
}
